//
//  ViewController.swift
//  yy_swift_day5
//
//  Created by elvy on 16/12/8.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    @IBOutlet weak var collectionView_pics: UICollectionView!
    private var picAllDescription = PicAllDescription.creatPicAllDesciption()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        collectionView_pics.dataSource = self
        collectionView_pics.delegate = self;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //MARK: - UICollectionView Delegate
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1;
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return picAllDescription.count;
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell : PicCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "PicCollectionViewCell", for: indexPath) as! PicCollectionViewCell
        //cell.label_title.text = "lalalla";
        //cell.imageView_pic.image = UIImage.init(named: "bodyline")
        cell.cellPicAllDescription = picAllDescription[indexPath.row];
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        print(String(indexPath.row))
        print(picAllDescription[indexPath.row].descriptions+"-----"+String(indexPath.row));
        
    }

}

