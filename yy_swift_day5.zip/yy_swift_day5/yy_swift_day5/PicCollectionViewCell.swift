//
//  PicCollectionViewCell.swift
//  yy_swift_day5
//
//  Created by elvy on 16/12/8.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

class PicCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView_pic: UIImageView!
    
    @IBOutlet weak var label_title: UILabel!
    
    var text_description: String = ""
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        self.layer.cornerRadius = 5.0
        
        self.clipsToBounds = true
        
    }
    
    var cellPicAllDescription : PicAllDescription! {
        didSet {
            updateUI()
        }
    }
    
    private func updateUI() {
        label_title.text = cellPicAllDescription.title
        text_description = cellPicAllDescription.descriptions
        imageView_pic.image = cellPicAllDescription.featureaImage
    }
    
    
}
