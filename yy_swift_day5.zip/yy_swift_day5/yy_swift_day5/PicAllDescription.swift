//
//  PicAllDescription.swift
//  yy_swift_day3
//
//  Created by elvy on 16/12/8.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

class PicAllDescription {
    
    var title : String
    var descriptions : String
    var featureaImage : UIImage!
    
    init(title:String, description:String, featureaImage:UIImage!) {
        self.title = title
        self.descriptions = description;
        self.featureaImage = featureaImage
    }
    
    static func creatPicAllDesciption() -> [PicAllDescription]{
        return [
            PicAllDescription(title: "Hello there, i miss u.", description: "We love backpack and adventures! We walked to Antartica yesterday, and camped with some cute pinguines, and talked about this wonderful app idea. 🐧⛺️✨", featureaImage: UIImage(named: "hello")!),
            PicAllDescription(title: "🐳🐳🐳🐳🐳", description: "We love romantic stories. We walked to Antartica yesterday, and camped with some cute pinguines, and talked about this wonderful app idea. 🐧⛺️✨", featureaImage: UIImage(named: "dudu")!),
            PicAllDescription(title: "Training like this, #bodyline", description: "Create beautiful apps. We walked to Antartica yesterday, and camped with some cute pinguines, and talked about this wonderful app idea. 🐧⛺️✨", featureaImage: UIImage(named: "bodyline")!),
            PicAllDescription(title: "I'm hungry, indeed.", description: "Cars and aircrafts and boats and sky. We walked to Antartica yesterday, and camped with some cute pinguines, and talked about this wonderful app idea. 🐧⛺️✨", featureaImage: UIImage(named: "wave")!),
            PicAllDescription(title: "Dark Varder, #emoji", description: "Meet life with full presence. We walked to Antartica yesterday, and camped with some cute pinguines, and talked about this wonderful app idea. 🐧⛺️✨", featureaImage: UIImage(named: "darkvarder")!),
            PicAllDescription(title: "I have no idea, bitch", description: "Get up to date with breaking-news. We walked to Antartica yesterday, and camped with some cute pinguines, and talked about this wonderful app idea. 🐧⛺️✨", featureaImage: UIImage(named: "hhhhh")!),
        ]
    }
    

}
