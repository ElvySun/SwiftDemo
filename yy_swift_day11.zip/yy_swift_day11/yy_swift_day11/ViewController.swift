//
//  ViewController.swift
//  yy_swift_day11
//
//  Created by elvy on 16/12/15.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var colorTableView : UITableView!
    var tableviewData = ["八一大商","樊振东小朋友","周雨弟弟","周恺酷盖","赵钢彦dd","宋旭大脸","尹航哥神","白告教练","队医萌","八一大商","樊振东小朋友","周雨弟弟","周恺酷盖","赵钢彦dd","宋旭大脸","尹航哥神","白告教练","队医萌"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        print("ono~~")
        
        view.backgroundColor = UIColor.black
        
        colorTableView = UITableView(frame: view.bounds, style:UITableViewStyle.plain);
        colorTableView.separatorStyle = UITableViewCellSeparatorStyle.none;
        
        colorTableView.dataSource = self;
        colorTableView.delegate = self;
        
        colorTableView.backgroundColor = UIColor.clear
        
        view .addSubview(colorTableView)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //MARK: - TableView Delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableviewData.count;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView .dequeueReusableCell(withIdentifier: "cell");
        if cell==nil {
            cell = ColorTableViewCell(style:UITableViewCellStyle.default, reuseIdentifier:"cell");
        }
        
        cell?.backgroundColor = colorForIndex(index: indexPath.row);
        cell?.textLabel?.backgroundColor = UIColor.clear
        cell?.textLabel?.textColor = UIColor.white;
        cell?.textLabel?.text = tableviewData[indexPath.row];
        cell?.textLabel?.font = UIFont(name: "Avenir Next", size: 18)
        cell?.selectionStyle = UITableViewCellSelectionStyle.none;
        
        return cell!
        
    }
    
    func colorForIndex(index:Int) -> UIColor {
        
        let colorItem = tableviewData.count - 1
        let color = CGFloat(index) / CGFloat(colorItem) * 0.6
        return UIColor(red:1.0, green:color, blue:0.0, alpha:1.0)
        
    }
    
}

