//
//  ColorTableViewCell.swift
//  yy_swift_day11
//
//  Created by elvy on 16/12/19.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

class ColorTableViewCell: UITableViewCell {
    
    let gradientLayer = CAGradientLayer()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override init(style:UITableViewCellStyle, reuseIdentifier:String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        let color1 = UIColor(white:1.0, alpha:0.2).cgColor as CGColor;
        let color2 = UIColor(white:1.0, alpha:0.1).cgColor as CGColor;
        let color3 = UIColor.clear.cgColor as CGColor;
        let color4 = UIColor(white:0.9, alpha:0.05).cgColor as CGColor;
        
        gradientLayer.colors = [color1, color2, color3, color4];
        gradientLayer.locations = [0.0, 0.04, 0.96,1.0];
        layer.insertSublayer(gradientLayer, at: 0);
        
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer.frame = self.bounds
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
