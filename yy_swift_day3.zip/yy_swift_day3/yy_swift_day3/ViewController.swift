//
//  ViewController.swift
//  yy_swift_day3
//
//  Created by elvy on 16/11/29.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, movieTableViewCellDelegate {
    
    //MARK: - 定义
    @IBOutlet weak var tableView_movie: UITableView!
    var moviePic = ["videoScreenshot01","videoScreenshot02","videoScreenshot03","videoScreenshot04","videoScreenshot05","videoScreenshot06"];
    let cellId = "cellIdentity" //获取CellId
    var avplayer = AVPlayer();
    var avplayController = AVPlayerViewController();
    
    
    
    
    //MARK: - 初始化
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView_movie.delegate = self;
        tableView_movie.dataSource = self;
        tableView_movie.allowsSelection = false;
        let nib = UINib(nibName: "movieTableViewCell", bundle: nil) //nibName指的是我们创建的Cell文件名
        tableView_movie.register(nib, forCellReuseIdentifier: cellId);
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //MARK: - tableview
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 220;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        /*
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentity);
        
        if cell == nil {
            cell = movieTableViewCell(style: UITableViewCellStyle.value1, reuseIdentifier: cellIdentity);
            
        }
         */
        let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as?
        movieTableViewCell
        cell?.imageView_bg?.image = UIImage.init(named: moviePic[indexPath.row]);
        cell?.button_play?.tag = indexPath.row;
        cell?.delegate = self;
        print("indexPath===" + String(indexPath.row));
        return cell!;
        
    }
    
    //MARK: - action
    func buttonClick(tag:Int) {
        print("buttonClick==" + String(tag));
        let path = Bundle.main.path(forResource: "emoji zone", ofType: "mp4");
        avplayer = AVPlayer(url:NSURL(fileURLWithPath: path!) as URL)
        avplayController.player = avplayer;
        self.present(avplayController, animated: true) {
            self.avplayController.player?.play()
        }
    }

    @IBAction func button_click_reload(_ sender: UIButton) {
        print("reload");
        tableView_movie.reloadData();
    }
}

