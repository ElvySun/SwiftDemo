//
//  movieTableViewCell.swift
//  yy_swift_day3
//
//  Created by elvy on 16/11/29.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

protocol movieTableViewCellDelegate {
    
    func buttonClick(tag:Int)
    
}

class movieTableViewCell: UITableViewCell {
    
    var delegate: movieTableViewCellDelegate?
    
    
    @IBOutlet weak var button_play: UIButton?
    @IBOutlet weak var imageView_bg: UIImageView?
    
    @IBAction func button_click_play(_ sender: UIButton) {
        print("button==" + String(sender.tag));
        self.delegate?.buttonClick(tag: sender.tag);
    }
    
    //MARK: - 初始化
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
