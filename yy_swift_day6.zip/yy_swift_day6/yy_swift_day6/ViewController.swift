//
//  ViewController.swift
//  yy_swift_day6
//
//  Created by elvy on 16/12/8.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    
    @IBOutlet weak var label_location: UILabel!
    @IBOutlet weak var button_findLocation: UIButton!
    
    var locationManager : CLLocationManager!
    var currLocation : CLLocation! //这个是保存定位信息的  别乱想哈

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        button_findLocation.layer.cornerRadius = 10.0
    }
    
    
    @IBAction func button_click_findMyLocation(_ sender: UIButton) {
        
        if CLLocationManager.locationServicesEnabled() == false {
            
            print("此设备不能定位")
            
            return
            
        }
        
        locationManager = CLLocationManager()
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;  //定位精度
        locationManager.distanceFilter = 1000.0
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
    }
    
    //MARK: - CLLocationManagerDelegate
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error while updating location ====" + error.localizedDescription)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("get location")
        
        currLocation = locations.last!
        print("经度：\(currLocation.coordinate.longitude) 纬度：\(currLocation.coordinate.latitude) 海拔：\(currLocation.altitude) 水平精度：\(currLocation.horizontalAccuracy) 垂直精度：\(currLocation.verticalAccuracy) 方向：\(currLocation.course) 速度：\(currLocation.speed)")
        
        LonLatToCity()
        /*
        CLGeocoder().reverseGeocodeLocation(manager.location!, completionHandler: {(placemarks, error)->Void in
            
            if (error != nil) {
                self.label_location.text = "Reverse geocoder failed with error" + error!.localizedDescription
                print("Reverse geocoder failed with error ====" + error!.localizedDescription)
                return
            }
            
            if placemarks!.count > 0 {
                let pm = placemarks![0]
                self.displayLocationInfo(placemark: pm)
            } else {
                self.label_location.text = "Problem with the data received from geocoder"
            }
        })
        */
    }
    


    
    func displayLocationInfo(placemark: CLPlacemark?) {
        if let containsPlacemark = placemark {
            locationManager.stopUpdatingLocation()
            
            let locality = (containsPlacemark.locality != nil) ? containsPlacemark.locality : ""
            let postalCode = (containsPlacemark.postalCode != nil) ? containsPlacemark.postalCode : ""
            let adminstrativeArea = (containsPlacemark.administrativeArea != nil) ? containsPlacemark.administrativeArea : ""
            let country = (containsPlacemark.country != nil) ? containsPlacemark.country : ""
            
            let string1 = locality! + postalCode!
            let string2 = adminstrativeArea! + country!
            
            self.label_location.text = string1 + string2
        }
        
    }
    
    
    func LonLatToCity() {
        
        let geocoder: CLGeocoder = CLGeocoder()
        
        geocoder.reverseGeocodeLocation(currLocation) { (placemark, errors) -> Void in
            
            
            
            if(errors == nil)//成功
                
            {
                
                let array = placemark! as NSArray
                
                let mark = array.firstObject as! CLPlacemark
                
                //这个是城市
                
                let city: String = (mark.addressDictionary! as NSDictionary).value(forKey: "City") as! String
                
                //这个是国家
                
                let country: NSString = (mark.addressDictionary! as NSDictionary).value(forKey: "Country") as! NSString
                
                //这个是国家的编码
                
                let CountryCode: NSString = (mark.addressDictionary! as NSDictionary).value(forKey: "CountryCode") as! NSString
                
                //这是街道位置
                
                let FormattedAddressLines: NSString = ((mark.addressDictionary! as NSDictionary).value(forKey: "FormattedAddressLines") as AnyObject).firstObject as! NSString
                
                //这是具体位置
                
                let Name: NSString = (mark.addressDictionary! as NSDictionary).value(forKey: "Name") as! NSString
                
                //这是省
                
                var State: String = (mark.addressDictionary! as NSDictionary).value(forKey: "State") as! String
                
                //这是区
                
                let SubLocality: NSString = (mark.addressDictionary! as NSDictionary).value(forKey: "SubLocality") as! NSString
                
                //我在这里去掉了“省”和“市” 项目需求 可以忽略
                
                State = State.replacingOccurrences(of: "省", with: "")
                
                let citynameStr = city.replacingOccurrences(of: "市", with: "")
                
                //在这里直接赋值给了之前定义的变量
                
                
                print( State)
                
                print( citynameStr)
                
                
            }
                
            else
                
            {
                
                print(errors!)
                print( "定位好像失败了哦")
                
            }
            
        }
        
    }
    
    
}

