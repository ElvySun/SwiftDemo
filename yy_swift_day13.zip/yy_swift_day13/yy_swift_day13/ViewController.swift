//
//  ViewController.swift
//  yy_swift_day13
//
//  Created by elvy on 16/12/20.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var colorTableView : UITableView!
    let tableData = ["借我十年","借我亡命天涯的勇敢","借我一束光，照亮黯淡","借我笑颜灿烂如春天","借我十年","借我亡命天涯的勇敢","借我一束光，照亮黯淡","借我笑颜灿烂如春天","借我十年","借我亡命天涯的勇敢","借我一束光，照亮黯淡","借我笑颜灿烂如春天","借我十年","借我亡命天涯的勇敢","借我一束光，照亮黯淡","借我笑颜灿烂如春天"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        view.backgroundColor = UIColor.black;
        
        colorTableView = UITableView(frame:view.bounds, style:UITableViewStyle.plain);
        colorTableView.backgroundColor = UIColor.clear;
        colorTableView.separatorStyle = UITableViewCellSeparatorStyle.none;
        
        colorTableView.dataSource = self;
        colorTableView.delegate = self;
        
        view .addSubview(colorTableView)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true);
        
        animateTable()
    }

    //MARK: - TableView Delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell");
        if cell == nil {
            cell = UITableViewCell (style:UITableViewCellStyle.default, reuseIdentifier: "cell");
        }
        
        cell?.textLabel?.textColor = UIColor.white;
        cell?.textLabel?.text = tableData[indexPath.row];
        cell?.textLabel?.backgroundColor = UIColor.clear;
        cell?.backgroundColor = colorForRow(index: indexPath.row);
        
        return cell!;
    }
    
    //MARK: - action
    func colorForRow(index:Int) -> UIColor {
        let num = tableData.count - 1
        let color = CGFloat(index) / CGFloat(num) * 0.6
        return UIColor(red:color, green:0.0, blue:0.6, alpha:1.0);
    }
    
    func animateTable() {
        
        colorTableView .reloadData()
        
        let cells = colorTableView.visibleCells
        let tableHeight :CGFloat = colorTableView.bounds.size.height;
        
        //CGAffineTransformMakeTranslation每次都是以最初位置的中心点为起始参照
        for i in cells {
            let cell : UITableViewCell = i as UITableViewCell
            cell.transform = CGAffineTransform(translationX: 0, y: tableHeight)
        }
        
        var index = 0
        
        for a in cells {
            
            let cell : UITableViewCell = a as UITableViewCell
            
            UIView.animate(withDuration: 1.5, delay: 0.05 * Double(index), usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: [], animations: {
                
                cell.transform = CGAffineTransform(translationX: 0, y: 0)
                
            }, completion: nil)
            
            index += 1
        }
        
    }

}

