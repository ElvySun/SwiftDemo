//
//  ViewController.swift
//  yy_swift_day7
//
//  Created by elvy on 16/12/12.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var refreshController = UIRefreshControl()
    var emojiTableView = UITableView()
    var tipNums = 0;
    
    let favoriteEmoji = ["🤗🤗🤗🤗🤗", "😅😅😅😅😅", "😆😆😆😆😆"]
    let newFavoriteEmoji = ["🏃🏃🏃🏃🏃", "💩💩💩💩💩", "👸👸👸👸👸", "🤗🤗🤗🤗🤗", "😅😅😅😅😅", "😆😆😆😆😆" ]
    var emojiData = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        emojiTableView = UITableView(frame:CGRect(x:0, y:0, width:view.frame.size.width, height:view.frame.size.height), style:.plain)
        emojiTableView.dataSource = self;
        emojiTableView.delegate = self;
        emojiTableView.backgroundColor = UIColor.black;
        emojiTableView.separatorStyle = UITableViewCellSeparatorStyle.none;
        
        refreshController .addTarget(self, action: #selector(didRelodEmoji), for: .valueChanged);
        emojiTableView.refreshControl = refreshController;
        
        view.backgroundColor = UIColor.black;
        
        refreshController.backgroundColor = UIColor.brown;
        let attributes = [NSForegroundColorAttributeName: UIColor.white]    //字的颜色
        refreshController.attributedTitle = NSAttributedString(string: "Last updated on \(NSDate())", attributes: attributes)
        refreshController.tintColor = UIColor.white     //小菊花的颜色  
        
        emojiData = favoriteEmoji;
        
        view .addSubview(emojiTableView)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - tableViewDelegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return emojiData.count;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60.0;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cer = "cell_emoji"
        var cell = tableView.dequeueReusableCell(withIdentifier:cer)
        if cell == nil {
            cell = UITableViewCell(style:UITableViewCellStyle.default, reuseIdentifier: cer);
        }
        
        cell?.textLabel?.text = emojiData[indexPath.row];
        cell?.backgroundColor = UIColor.black
        
        return cell!;
    }
    
    //MARK: - action
    func didRelodEmoji() {
        tipNums += 1;
        switch tipNums%2 {
        case 0:
            emojiData = favoriteEmoji;
            break;
        case 1:
            emojiData = newFavoriteEmoji;
            break;
        default:
            break;
        }
        
        emojiTableView .reloadData();
        refreshController .endRefreshing();
        
    }


}

