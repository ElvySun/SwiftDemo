//
//  LoginViewController.swift
//  yy_swift_day12
//
//  Created by elvy on 16/12/19.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var textfield_username: UITextField!
    @IBOutlet weak var textfield_password: UITextField!
    @IBOutlet weak var button_login: UIButton!
    
    @IBOutlet weak var layoutCenter_username: NSLayoutConstraint!
    @IBOutlet weak var layoutCenter_password: NSLayoutConstraint!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        button_login.layer.cornerRadius = 5;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true);
        
        button_login.alpha = 0
        layoutCenter_password.constant -= view.bounds.width;
        layoutCenter_username.constant -= view.bounds.width;
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        
        UIView .animate(withDuration: 0.5, delay: 0.0, options: UIViewAnimationOptions.curveEaseOut, animations: {
            
            self.layoutCenter_username.constant += self.view.bounds.width;
            self.view.layoutIfNeeded();
            
        }, completion: nil)
        
        UIView .animate(withDuration: 0.5, delay: 0.1, options: UIViewAnimationOptions.curveEaseOut, animations: {
            
            self.layoutCenter_password.constant += self.view.bounds.width;
            self.view.layoutIfNeeded();
            
        }, completion: nil)
        
        UIView .animate(withDuration: 0.5, delay: 0.2, options: UIViewAnimationOptions.curveEaseOut, animations: {
            
            self.button_login.alpha = 1;
            
        }, completion: nil)
        
    }
    
    @IBAction func button_click_login(_ sender: UIButton) {
        
        let bounds = button_login.bounds;
        
        //usingSpringWithDamping：弹簧动画的阻尼值
        //initialSpringVelocity：弹簧动画的速率
        UIView .animate(withDuration: 1.0, delay: 0.0, usingSpringWithDamping: 0.2, initialSpringVelocity: 10, options: UIViewAnimationOptions.curveLinear, animations: {
            
            self.button_login.bounds = CGRect(x:bounds.origin.x-30, y:bounds.origin.y, width:bounds.width+60, height:bounds.height);
            self.button_login.isEnabled = false;
            
        }, completion: {
            finished in self.button_login.isEnabled = true
        })
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
