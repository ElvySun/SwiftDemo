//
//  ViewController.swift
//  yy_swift_day12
//
//  Created by elvy on 16/12/19.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var button_signup: UIButton!
    @IBOutlet weak var button_login: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        button_signup.layer.cornerRadius = 5;
        button_login.layer.cornerRadius = 5;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

