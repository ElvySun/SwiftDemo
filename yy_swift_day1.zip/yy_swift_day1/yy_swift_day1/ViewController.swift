//
//  ViewController.swift
//  yy_swift_day1
//
//  Created by elvy on 16/11/28.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var label_time: UILabel!
    @IBOutlet weak var button_reset: UIButton!
    @IBOutlet weak var button_stop: UIButton!
    @IBOutlet weak var button_start: UIButton!
    var double_time = 0.0;
    var timer: Timer!
    var isStop = false
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        label_time.text = String(0.0);
        
        button_stop.isEnabled = false;
        button_reset.isEnabled = false;
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func button_click_reset(_ sender: UIButton) {
        print("reset");
        //关闭计时器
        timer.invalidate();
        label_time.text = String(0.0);
        double_time = 0.0;
        isStop = false;
        
        button_start.isEnabled = true;
        button_stop.isEnabled = false;
        button_reset.isEnabled = false;
    }
    
    @IBAction func button_click_start(_ sender: UIButton) {
        
        if isStop {
            //重启计时器
            timer.fireDate = NSDate.distantPast;
            print("isStop = yes");
            isStop = false;
        } else {
            //开始计时器
            timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector:#selector(addTimer) , userInfo: nil, repeats: true);
            print("isStop = no");
        }
        
        button_start.isEnabled = false;
        button_stop.isEnabled = true;
        button_reset.isEnabled = true;
        
    }

    @IBAction func button_click_stop(_ sender: UIButton) {
        print("stop");
        //暂停计时器
        timer.fireDate = NSDate.distantFuture;
        isStop = true;
        
        button_start.isEnabled = true;
        button_stop.isEnabled = false;
        button_reset.isEnabled = true;
    }
    
    func addTimer() {
        double_time += 0.1;
        label_time.text = String(format:"%.1f",double_time);
        print(String(format:"%.1f",double_time));
    }

}

