//
//  ViewController.swift
//  yy_swift_day9
//
//  Created by elvy on 16/12/12.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {
    
    var imageView : UIImageView!
    var scrollView : UIScrollView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // ImageView
        imageView = UIImageView(image: UIImage(named:"Steve"))
        
        // ScrollView
        scrollView = UIScrollView(frame: view.bounds)
        scrollView.backgroundColor = UIColor.black;
        scrollView.contentSize = imageView.bounds.size    //内容大小
        
        scrollView .addSubview(imageView);
        scrollView.delegate = self;
        view .addSubview(scrollView);
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        let imageSize = imageView.bounds.size;
        let scrollSize = scrollView.bounds.size;
        let widthScale = scrollSize.width/imageSize.width;
        let heightScale = scrollSize.height/imageSize.height;
        scrollView.minimumZoomScale = min(widthScale, heightScale);
        scrollView.maximumZoomScale = 3.0;
        
        if scrollView.zoomScale < scrollView.minimumZoomScale {
            scrollView.zoomScale = scrollView.minimumZoomScale
        }
        
        recenterImage()
    }
    
    private func recenterImage() {
        
        //图片和scrollview的距离
        let scrollViewSize = scrollView.bounds.size
        let imageViewSize = imageView.frame.size
        let horizontalSpace = imageViewSize.width < scrollViewSize.width ? (scrollViewSize.width - imageViewSize.width) / 2.0 : 0
        let verticalSpace = imageViewSize.height < scrollViewSize.height ? (scrollViewSize.height - imageViewSize.width) / 2.0 :0
        
        scrollView.contentInset = UIEdgeInsetsMake(verticalSpace, horizontalSpace, verticalSpace, horizontalSpace)
        
    }
    
    
    //MARK: - ScrollViewDelegate
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return imageView
    }
    
    func scrollViewDidZoom(_ scrollView: UIScrollView) {
        recenterImage()
    }


}

