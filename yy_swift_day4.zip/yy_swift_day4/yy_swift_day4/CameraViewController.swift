//
//  CameraViewController.swift
//  yy_swift_day4
//
//  Created by elvy on 16/11/30.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit
import AVFoundation

class CameraViewController: UIViewController, AVCapturePhotoCaptureDelegate {
    
    //MARK - 定义
    var captureSession : AVCaptureSession?
    var stillImageOutput : AVCapturePhotoOutput?
    var previewLayer : AVCaptureVideoPreviewLayer?
    var input : AVCaptureDeviceInput?
    @IBOutlet weak var view_camera: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true);
        
        
        captureSession = AVCaptureSession();
        captureSession?.sessionPreset = AVCaptureSessionPreset1920x1080;
        
        let backCamera = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo); //相机使用
        
        if (backCamera == nil) {
            print("cacaca");
        }
        var err : NSError?
        
        
        do {
            input = try AVCaptureDeviceInput(device: backCamera) }
        catch let error as NSError {
            err = error
            input = nil
        }
        
        if err != nil {
            print("error: \(err?.localizedDescription)")
        }
        
        if (err == nil && captureSession?.canAddInput(input!) != nil) {
            
            captureSession?.addInput(input)
            stillImageOutput = AVCapturePhotoOutput()
            
            
            if (captureSession?.canAddOutput(stillImageOutput) != nil) {
                captureSession?.addOutput(stillImageOutput);
                
                previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
                previewLayer?.videoGravity = AVLayerVideoGravityResizeAspect
                previewLayer?.connection.videoOrientation = AVCaptureVideoOrientation.portrait
                previewLayer?.frame = view_camera.bounds
                view_camera.layer.addSublayer(previewLayer!)
                captureSession?.startRunning();
            }
 
        }
        
        
 
    }
    
    //MARK - action
    
    func button_click_changePhone(sender: UIButton) {
        print("lallala");
        guard var position = input?.device.position else { return }
        // 2:获取当前显示的镜头
        position = position == .front ? .back : .front
        print("position==",position);
        
    }
    
    func tapped(sender:UIButton){
        print("tapped")
    }
    
    
    func btnClick(sender:UIButton){
        print("按钮被点击")
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
