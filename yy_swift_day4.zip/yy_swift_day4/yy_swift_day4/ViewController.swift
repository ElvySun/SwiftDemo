//
//  ViewController.swift
//  yy_swift_day4
//
//  Created by elvy on 16/11/30.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //MARK - 定义
    @IBOutlet weak var myScrollView: UIScrollView!
    
    
    //MARK - 初始化
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let leftView : LeftViewController = LeftViewController(nibName:"LeftViewController", bundle:nil);
        let cameraView : CameraViewController = CameraViewController(nibName:"CameraViewController", bundle:nil);
        let rightView : RightViewController = RightViewController(nibName:"RightViewController", bundle:nil);
        
        
        myScrollView .addSubview(leftView.view);
        myScrollView .addSubview(cameraView.view);
        myScrollView .addSubview(rightView.view);
        
        leftView.buttona .addTarget(self, action: #selector(yoyoyo), for: .touchUpInside);
        
        var cameraviewFrame : CGRect = cameraView.view.frame;
        cameraviewFrame.origin.x = self.view.frame.width;
        cameraView.view.frame = cameraviewFrame;
        
        var rightviewFrame : CGRect = rightView.view.frame;
        rightviewFrame.origin.x = self.view.frame.width*2;
        rightView.view.frame = rightviewFrame;

        
        myScrollView.contentSize = CGSize(width: self.view.frame.width*3, height: self.view.frame.size.height);
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func buttonTapped(sender: UIButton) {
        print("hello")
    }
    
    func yoyoyo() {
        print("ssss");
        print("我要嫁给张继科")
    }


}

