//
//  ViewController.swift
//  yy_swift_day2
//
//  Created by elvy on 16/11/28.
//  Copyright © 2016年 elvy. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - 定义
    
    @IBOutlet weak var tableview_font: UITableView!
    @IBOutlet weak var button_change: UIButton!
    
    var fontFamily = ["MFJinHei_Noncommercial-Regular", "MFTongXin_Noncommercial-Regular", "MFZhiHei_Noncommercial-Regular"];
    var yy_txt = ["11月28日", "yy_swift_day2", "yy同学养了一科雨", "当潮流爱新鲜", "当旁人爱标签", "无条件"];
    
    var fontNum = 0
    
    // MARK: - 初始化

    override func viewDidLoad() {
        super.viewDidLoad()
        
        fontNum = 0;
        
        
        tableview_font.separatorStyle = UITableViewCellSeparatorStyle.none;
        tableview_font.allowsSelection = false;
        tableview_font.dataSource = self;
        tableview_font.delegate = self;
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true);
        button_change.layer.cornerRadius = 50;
    }
    
    // MARK: - action

    @IBAction func button_click_changeFonts(_ sender: UIButton) {
        fontNum = fontNum+1
        fontNum = fontNum%3
        print("fontNum===" + String(fontNum));
        
        tableview_font.reloadData();
    }
    
    // MARK: - TableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentity = "cell";
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentity);
        if !(cell != nil) {
            print("cell == nil");
            cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: cellIdentity);
        }
        
        cell?.textLabel?.text = yy_txt[indexPath.row];
        cell?.textLabel?.font = UIFont(name:fontFamily[fontNum], size:16)
        cell?.textLabel?.textColor = UIColor.white;
        cell?.backgroundColor = UIColor.init(red: 51/255.0, green: 51/255.0, blue: 51/255.0, alpha: 1.0)
        
        return cell!;
        
        
    }
    

}

